let hours_worked = 3110
